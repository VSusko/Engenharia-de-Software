/*
#include "model_impl.h"
#include "flow_impl.h"
#include "system_impl.h"


int main() {
    ModelImpl model;
    model.simulate(0, 10, 1);
    return 0;
}
*/